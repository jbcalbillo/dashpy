import streamlit as st
import pandas as pd
import json
import altair as alt
import pydeck as pdk

# Configuración de la página - debe estar al principio
st.set_page_config(
    page_title="Dashboard de Candidatos",
    layout="wide"
)

# Título del Dashboard
st.title("Dashboard de Candidatos por Localidad")

# Cargar los datos JSON y CSV
with open('src/candidatos2024.json') as f:
    data = json.load(f)

coordenadas_df = pd.read_csv('src/data.csv')

# Convertir datos a DataFrame
df = pd.DataFrame(data)

# Crear un desplegable con las localidades únicas
localidades = df['localidad'].unique()
localidad_seleccionada = st.selectbox("Selecciona una Localidad", localidades)

# Filtrar los datos según la localidad seleccionada
df_localidad = df[df['localidad'] == localidad_seleccionada]

# Agrupar datos según criterios solicitados
agrupado_marca = df_localidad.groupby('marcaPostula').size().reset_index(name='cantidad')
agrupado_puesto = df_localidad.groupby('puestoPostula').size().reset_index(name='cantidad')
agrupado_edad = df_localidad.groupby('edad').size().reset_index(name='cantidad')
agrupado_estatus = df_localidad.groupby('estatusCandidato').size().reset_index(name='cantidad')

# Mostrar tabla y gráfico por Marca
st.subheader(f"Distribución de Candidatos por Marca en {localidad_seleccionada}")
st.table(agrupado_marca)

chart_marca = alt.Chart(agrupado_marca).mark_bar(color='#4CAF50').encode(
    x=alt.X('marcaPostula:O', title='Marca'),
    y=alt.Y('cantidad:Q', title='Cantidad'),
    tooltip=['marcaPostula', 'cantidad']
).properties(
    width=600,
    height=400
)
st.altair_chart(chart_marca, use_container_width=True)

# Mostrar tabla y gráfico por Puesto
st.subheader(f"Distribución de Candidatos por Puesto en {localidad_seleccionada}")
st.table(agrupado_puesto)

chart_puesto = alt.Chart(agrupado_puesto).mark_bar(color='#FF9800').encode(
    x=alt.X('puestoPostula:O', title='Puesto'),
    y=alt.Y('cantidad:Q', title='Cantidad'),
    tooltip=['puestoPostula', 'cantidad']
).properties(
    width=600,
    height=400
)
st.altair_chart(chart_puesto, use_container_width=True)

# Mostrar tabla y gráfico por Edad
st.subheader(f"Distribución de Candidatos por Edad en {localidad_seleccionada}")
st.table(agrupado_edad)

chart_edad = alt.Chart(agrupado_edad).mark_bar(color='#2196F3').encode(
    x=alt.X('edad:O', title='Edad'),
    y=alt.Y('cantidad:Q', title='Cantidad'),
    tooltip=['edad', 'cantidad']
).properties(
    width=600,
    height=400
)
st.altair_chart(chart_edad, use_container_width=True)

# Mostrar tabla y gráfico por Estatus
st.subheader(f"Distribución de Candidatos por Estatus en {localidad_seleccionada}")
st.table(agrupado_estatus)

chart_estatus = alt.Chart(agrupado_estatus).mark_bar(color='#9C27B0').encode(
    x=alt.X('estatusCandidato:O', title='Estatus'),
    y=alt.Y('cantidad:Q', title='Cantidad'),
    tooltip=['estatusCandidato', 'cantidad']
).properties(
    width=600,
    height=400
)
st.altair_chart(chart_estatus, use_container_width=True)

# Visualizar en un Mapa
st.subheader(f"Mapa de Candidatos en {localidad_seleccionada}")

# Mergear el DataFrame agrupado con el DataFrame de coordenadas
merged_df = pd.merge(df_localidad.groupby('localidad').size().reset_index(name='cantidad'), 
                     coordenadas_df, left_on="localidad", right_on="NOM_ENT", how="left")

# Crear una capa de puntos utilizando ScatterplotLayer
scatter_layer = pdk.Layer(
    "ScatterplotLayer",
    data=merged_df,
    get_position='[LON_DEC, LAT_DEC]',
    get_radius=20000,
    get_color='[200, 30, 0, 160]',
    pickable=True,
)

# Crear una capa de texto utilizando TextLayer para mostrar la cantidad de candidatos
text_layer = pdk.Layer(
    "TextLayer",
    data=merged_df,
    get_position='[LON_DEC, LAT_DEC]',
    get_text='cantidad',
    get_color='[255, 255, 255, 255]',
    get_size=24,
    get_alignment_baseline="'middle'",
)

# Configurar la vista inicial del mapa
view_state = pdk.ViewState(
    latitude=23.634501,
    longitude=-102.552784,
    zoom=5,
    pitch=50,
)

# Configurar el estilo del mapa utilizando Mapbox
map_style = "mapbox://styles/mapbox/light-v10"

# Mostrar el mapa con las capas de puntos y texto
st.pydeck_chart(pdk.Deck(
    layers=[scatter_layer, text_layer],
    initial_view_state=view_state,
    map_style=map_style,
    tooltip={"text": "{localidad}\nCantidad: {cantidad}"}
))
